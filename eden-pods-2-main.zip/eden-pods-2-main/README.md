# 🌱 Eden Pods — Food Forest Tracker

**Throw a seed pod. Grow a food forest. Track it here.**

Eden Pods are biodegradable seed capsules containing AI-curated mixes of
resilient, high-nutrition plants. This app lets you log pod throws, track
growth stages, log harvests, and manage your Birthright Forest Kit.
